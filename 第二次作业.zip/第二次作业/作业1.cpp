﻿//代码链接：https://github.com/lengender/A-star/blob/master/A-star.cpp
#include <iostream>
#include <cassert>
#include <cmath>
#include <fstream>
using namespace std;

//the numbers of max vertices
//定义一个常量：最大顶点数100
const int MAX_NUM = 100;

//struct of edge
//定义边结构体
typedef struct EdgeNode {
    char start;//定义起点
    char end;//定义终点
    int weight;//定义宽度
    struct EdgeNode* next;//定义一个指向下一个边节点的指针
}EdgeNode;//整段就是定义了一个边结构体后用typedef来规定用缩写EdgeNode来代指边结构体

//struct of vertex
//定义顶点结构体
typedef struct VertexNode
{
    char name;//定义名称
    int x, y;//定义横纵坐标
    EdgeNode* head;//指向链表头部的指针
}VertexNode;//依旧缩写

//the number of vertices and edges
//初始化顶点数和边数
int vexNum = 0;
int edgeNum = 0;

//adjex 
//定义邻接表数组，最多容纳MAX_NUM个顶点
VertexNode adjList[MAX_NUM];

//priority queue element
//优先队列中的元素
typedef struct Element
{
    char vex;//定义顶点
    char parent;//定义父节点
    int x;//横坐标
    int y;//纵坐标
    int gval;//定义权值
    double fval;//定义一个浮点数值变量？

}Element;//缩写

class PQueue
{
public://构造函数
    PQueue() {
        size = 0;//初始化已存入元素个数
        data = new Element[MAX_NUM];//规定可存入元素的最大值
    }

    //insert a new element to priority queue
    void push(Element num)//元素入队
    {
        data[size] = num;//把新的元素放入队尾
        size++;//数量+1
        up(size - 1);//向上堆调整
    }

    Element front()
    {
        Element res = data[0];//取值最小的节点出来
        //delete the first element
        data[0] = data[size - 1];//把最末尾的节点移到最顶端，防止取出顶端节点后二叉树结构崩溃
        size--;//数量-1
        down(0);//向下堆调整
        return res;//返回取出的最优节点
    }

    //judge element is or not in priority queue
    int inPriQueue(char vex)//判断顶点是否在队列中
    {
        for (int i = 0; i < size; ++i)//遍历队列
        {
            if (data[i].vex == vex)
                return i;//找到返回下标
        }

        return -1;//没找到返回-1
    }

    //adjust element's fval
    //调整元素的节点综合评分并重新堆排序
    void adjustFval(Element e, int index)
    {
        data[index] = e;
        for (int i = (size - 1) / 2; i >= 0; --i)
            down(i);
    }

    ~PQueue()//析构函数
    {
        if (data)
            delete[] data;
        data = NULL;
    }

private:
    void down(int index)//向下堆调整函数
    {
        assert(index >= 0);
        Element tmp = data[index];//创建一个临时变量来存储当前节点数据
        index = index * 2 + 1;//把下标更新为左孩子的下标
        while (index < size)
        {
            if (index + 1 < size && data[index].fval > data[index + 1].fval)//如果满足当前下标还有下一位（也就是父节点的右孩子）而且左孩子节点综合评分大于右孩子的节点综合评分
                index++;//坐标+1，相当于后移
            if (data[index].fval > tmp.fval) break;//左孩子的节点综合评分大于父节点的节点综合评分，则不移动
            else
            {
                data[(index - 1) / 2] = data[index];//把左孩子的数据转移到父节点上
                index = index * 2 + 1;//当前下标变成下一个左孩子的坐标
            }
        }
        data[(index - 1) / 2] = tmp;//若循环执行，则把临时变量的值还给原左孩子节点（现父节点）；若不执行则把数据归还给原下标节点
    }

    void up(int index)//向上堆调整函数
    {
        assert(index < size);
        Element tmp = data[index];//把当前下标的数据传入临时变量
        while (index > 0 && tmp.fval < data[(index - 1) / 2].fval)//当下标大于0且当前下标的节点综合评分小于父节点的节点综合评分
        {
            data[index] = data[(index - 1) / 2];//把父节点的数据传到当前下标节点
            index = (index - 1) / 2;//下标更新为原父节点下标
        }
        data[index] = tmp;//若循环执行，则把临时变量的数据传到原父节点的位置；若不执行则把数据归还到原下标节点
    }

public:
    bool isEmpty()//判断队列是否为空
    {
        return size == 0;
    }

    bool smallerFval(int index, int fval)//对比指定下标元素的fval和传入数值
    {
        if (data[index].fval > fval)
            return true;

        return false;
    }

public:
    Element* data;//定义一个指向Element类型数组的指针
    int size;
};


//get the index of adjList by the vertex
int getIndexByVertex(VertexNode adjList[], int num, char start)//根据传入顶点的名字来查找它的下标
{
    for (int i = 0; i < num; ++i)
    {
        if (adjList[i].name == start)//若遍历出与传入的顶点名字一样的对应下标，则传出
            return i;
    }

    return -1;//否则返回-1
}

//judge the vertex is or not visited
int isVisited(Element closed[], int num, char name)//close表
{
    for (int i = 0; i < num; ++i)//依旧遍历
    {
        if (closed[i].vex == name)
            return i;
    }

    return -1;
}

//compute two vertices of Euclidean distance
//计算两个顶点之间的欧氏距离
double distance(int x1, int y1, int x2, int y2)//定义两点的横纵坐标
{
    return sqrt((x1 - x2) * (x1 - x2) * 1.0 + (y1 - y2) * (y1 - y2) * 1.0);//返回两点之间的距离（两点间的距离公式）
}

//print shortest path
//逆向回溯打印最短路径
void printPath(Element closed[], int num, char start, char end)
{
    char path[MAX_NUM];
    int size = 0;

    for (; ;) {
        for (int i = 0; i < num; ++i) {
            if (closed[i].vex == end)
            {
                path[size++] = end;//把这个顶点存入path数组
                end = closed[i].parent;//把end更新成父节点
                break;
            }
        }

        if (end == 0)//当parent==0时，也就是没有父节点了，已经回溯完整条路线
            break;
    };

    cout << "the shortest path is: ";
    for (int i = size - 1; i >= 0; --i)
    {
        cout << path[i] << " ";
    }//反转顺序打印
    cout << endl;
}

//A start algorithm to compute shortest path
int AstarShortestPath(char start, char end)
{
    int shortestPath = 0;
    PQueue priQ;//定义一个优先队列
    Element closed[MAX_NUM];//定义一个close表
    int num = 0, pos = 0;//定义并初始化num（close表里节点数量）和pos（临时存放单个节点在整个图的下标位置）

    //get the index by start and end vertex   
    int s_index = getIndexByVertex(adjList, vexNum, start);//读取起点坐标
    int e_index = getIndexByVertex(adjList, vexNum, end);//读取终点坐标

    //init a element by start vertex
    Element e;//定义一个Element类型的局部变量
    e.vex = start;//赋值顶点名
    e.x = adjList[s_index].x;//赋值横坐标
    e.y = adjList[s_index].y;//赋值纵坐标
    e.parent = 0;//起点无父节点
    e.gval = 0;//起点已走的距离为0
    e.fval = 0;//起点节点的节点综合评分为0
    priQ.push(e);  //把起点节点送进优先节点

    while (!priQ.isEmpty())//优先队列不为空
    {
        Element tmp = priQ.front();//把堆顶fval最小的节点取出到临时变量
        closed[num++] = tmp;  //将其放入close列表
        if (tmp.vex == end)   //如果该节点是终点
        {
            //打印路径及长度
            printPath(closed, num, start, end);
            cout << "the shortest path length is: " << tmp.gval << endl;//打印路径长度
            shortestPath = tmp.gval;
            break;
        }

        int index = getIndexByVertex(adjList, vexNum, tmp.vex);//取下标
        EdgeNode* ptr = adjList[index].head;//让指针ptr指向当前顶点的第一条邻接边
        //handle the adjacent vertex
        while (ptr)
        {
            Element t;//定义一个邻居对象
            pos = getIndexByVertex(adjList, vexNum, ptr->end);//调用函数查找这个邻居的下标
            t.vex = ptr->end;//邻居顶点名
            t.x = adjList[pos].x;//邻居坐标
            t.y = adjList[pos].y;
            t.parent = ptr->start;//邻居父节点
            t.gval = tmp.gval + ptr->weight;//邻居节点的gval等于当前节点gval加上当前节点通往邻居节点的路程
            t.fval = t.gval + distance(t.x, t.y, adjList[e_index].x, adjList[e_index].y);//邻居节点的fval等于gval加欧氏距离

            //如果邻居已在close表里，直接跳过
            if (isVisited(closed, num, ptr->end) != -1)
            {
                ptr = ptr->next;
                continue;
            }
            else
            {
                //judge this vertex is or not in priority queue
                int pri_index = priQ.inPriQueue(ptr->end);
                if (pri_index == -1)//若不在优先队列
                {
                    priQ.push(t);//加入优先队列
                }
                else {//已在优先队列
                    //if it's fval is smaller, adjust the element
                    if (priQ.smallerFval(pri_index, t.fval))//判断该节点是不是最优
                        priQ.adjustFval(t, pri_index);//调用adjustFval重新调整堆结构排序
                }
                ptr = ptr->next;//指针跳到下一条邻接边
            }
        }
    }

    return shortestPath;//打印最短路径
}


int main(int argc, char* argv[])//命令行参数个数、命令行参数字符串数组
{
    if (argc != 2)//合法运行要有一个文件参数，否则不能运行
    {
        cout << "./usage filename" << endl;
        return 0;
    }

    ifstream in;//文件读取输入流
    in.open(argv[1]);//打开

    in >> vexNum >> edgeNum;//读取顶点数和边数
    VertexNode tmp;

    for (int i = 0; i < vexNum; ++i) {//循环读取顶点信息
        in >> tmp.name >> tmp.x >> tmp.y;
        tmp.head = NULL;
        adjList[i] = tmp;//把信息存入全局邻接数组
    }

    //for(int i = 0; i < vexNum; ++i)
      //  cout << adjList[i].name << " " << adjList[i].x << " " << adjList[i].y << endl;

    EdgeNode eArr[MAX_NUM];//定义一个临时数组
    int index = 0;
    for (int i = 0; i < edgeNum; ++i)//循环读取
    {
        EdgeNode* e = new EdgeNode;//创建一个边界点
        in >> e->start >> e->end >> e->weight;//依次读取起点 终点 权重
        e->next = NULL;//新边暂时没有下一条边
        eArr[i].start = e->start;//放入数组备份
        eArr[i].end = e->end;
        eArr[i].weight = e->weight;

        index = getIndexByVertex(adjList, vexNum, e->start);//根据边起点的名称查找下标

        if (adjList[index].head == NULL)//无邻边就作为第一条边
        {
            adjList[index].head = e;
        }
        else {//新边指向原来的表头
            e->next = adjList[index].head;
            adjList[index].head = e;
        }
    }

    char start, end;
    in >> start >> end;//读取起点终点

    AstarShortestPath(start, end);//启动A*算法
    return 0;
}

#!/bin/bash
mkdir linux_practice
cd linux_practice
mkdir docs
mkdir backup
cd docs
touch readme.txt
touch notes.log
touch temp.tmp
rm temp.tmp
mv notes.log daily_report.txt
echo "Project Status:Active" > daily_report.txt
date +%Y-%m-%d >> daily_report.txt
cd ..
cp -r docs/* backup/
chmod 444 backup/*
echo "Archive Complete.File [backup] is now read-only"
